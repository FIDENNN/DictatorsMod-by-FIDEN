v#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Includes/Vector3.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Icon.h>
#include <Chams.h>
extern "C" {
    /*Time For Bools And all*/
    

    bool goldHack, caravanshack, expeditionshack, rebelshack = false;

    
    struct My_Patches {MemoryPatch Rebelsdaje;} hexPatches;
    const char *libName = "libil2cpp.so";
    /*For Menu*/
    JNIEXPORT jstring JNICALL
    Java_il2cpp_Main_apk(
        JNIEnv *env,
        jobject activityObject) {
    jstring str = env->NewStringUTF("ASP MODS");// do not earse the space this for normal text view
    return str;
}
    JNIEXPORT jstring JNICALL
    Java_il2cpp_Main_down(
        JNIEnv *env,
        jobject activityObject) {
    jstring str = env->NewStringUTF("Dictators | Mod by @FIDENNN");
        return str;
    }
    
    JNIEXPORT jstring JNICALL
Java_il2cpp_typefaces_Menu_gettype(
        JNIEnv *env,
        jobject activityObject) {
            
    jstring str = env->NewStringUTF("koll.ttf");
    return str;
}
    
    JNIEXPORT jobjectArray  JNICALL
Java_il2cpp_Main_getFeatures(
        JNIEnv *env,
        jobject activityObject) {
    jobjectArray ret;
    //"HL1_TEST",
    //"HL2_Kill",
    //"CRASH_Test Menu",
    //"SeekBar_Set Red_0_255",
    //"KIRA_Hide Icon",
    const char *features[] = {
            

            "Button_Gold Hack";
            "Button_Caravan Speed Hack",//0
            "Button_Expedition team Speed Hack",//0
            "Button_Rebels never start a war",//0

               
            "Text_Menu Settings",
            "ButtonHide_Make Icon invisible"};
            

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
} 
JNIEXPORT void JNICALL
Java_il2cpp_Main_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint value) {
    switch (feature) {
    
    case 0:
    goldHack = !goldHack;
    break;

    case 1:
    caravanshack = !caravanshack;
    break;

    case 2:
    expeditionshack = !expeditionshack;
    break;

    case 3:
    rebelshack = !rebelshack;
    if (rebelshack) {
    hexPatches.Rebelsdaje.Modify();
    }
    break;




    
      
			
    }
}
JNIEXPORT jstring JNICALL
Java_il2cpp_typefaces_Menu_SliderString(
        JNIEnv *env,
        jobject clazz, jint feature, jint value) {
    // You must count your features from 0, not 1
    const char *SliderStr;
    if (feature == 95) {
        switch (value) {
            case 0:
                SliderStr = "Default";
                break;
            case 1:
                SliderStr = "2x";
                break;
            case 2:
                SliderStr = "4x";
                break;
            case 3:
                SliderStr = "8x";
                break;
            case 4:
                SliderStr = "12x";
                break;
            case 5:
                SliderStr = "24x";
                break;
        }
        return env->NewStringUTF(SliderStr);
    }
    if (feature == 97) {
        switch (value) {
            case 0:
                SliderStr = "Neck";
                break;
            case 1:
                SliderStr = "Hip";
                break;
            case 2:
                SliderStr = "Head";
                break;
        }
        return env->NewStringUTF(SliderStr);
    }
    if (feature == 96) {
        if (value <= 15){
            SliderStr = "Low";
        }
        else if (value >= 15 && value <= 35){
            SliderStr = "Medium";
        }
        else if (value >= 35){
            SliderStr = "High";
        }
        return env->NewStringUTF(SliderStr);
    }
    return env->NewStringUTF(NULL);
}
}
// ---------- Hooking ---------- //





float (*old_InfinityGold)(void *instance);
float InfinityGold(void *instance) {
    if (instance != NULL) {
        if (goldHack) {
            return 5000.0; 
        }
    }
    
    return old_InfinityGold(instance);

}



void (*old_CaravanUpdate)(void *instance);
void CaravanUpdate(void *instance){
    if(instance != NULL){
        if (caravanshack) {
//private float speed           public class Caravan : MonoBehaviour
        *(float *)((uint64_t)instance + 0x48) = 50.0f;
        }

    }
    old_CaravanUpdate(instance);
}

void (*old_ExpeditionUpdate)(void *instance);
void ExpeditionUpdate(void *instance){
    if(instance != NULL){
        if (expeditionshack) {
//private float speed            public class ExpeditionTeam
        *(float *)((uint64_t)instance + 0x1C) = 50.0f;
        }

    }
    old_ExpeditionUpdate(instance);
}













void *hack_thread(void *) {
    
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
   
												
    // ---------- Hook ---------- //

MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x5E5748), (void *) InfinityGold, (void **) &old_InfinityGold); //metod : public float GetGold()     class= public class CentralAdmin : MonoBehaviour  
MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x5E2C44), (void *) CaravanUpdate, (void **) &old_CaravanUpdate);//metod : private void Update() { }     class= public class Caravan : MonoBehaviour
MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x5F3C78), (void *) ExpeditionUpdate, (void **) &old_ExpeditionUpdate);//metod : private void Update() { }     class= public class ExpeditionTeam : MonoBehaviour 

                   


 hexPatches.Rebelsdaje = MemoryPatch::createWithHex("libil2cpp.so", 0x9DDB44, "1E FF 2F E1");

    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
