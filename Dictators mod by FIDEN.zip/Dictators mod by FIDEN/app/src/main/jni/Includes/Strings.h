#pragma once
#include <sstream>
#include <codecvt>
typedef struct _monoString {
    void* klass;
    void* monitor;
    int32_t length;
    char chars[32];
    std::string get_string() {
        std::u16string u16_string(reinterpret_cast<const char16_t*>(getChars()));
        std::wstring wide_string(u16_string.begin(), u16_string.end());
        std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> convert;
        return convert.to_bytes(wide_string);
    }
    void set(std::string toconv){
        strcpy(chars, toconv.c_str());
    }
    char *getChars() {
        return chars;
    }
} monoString;
monoString *CreateMonoString(const char *str) {
    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress("libil2cpp.so", 0x13E0888);
    return String_CreateString(NULL, str);
}